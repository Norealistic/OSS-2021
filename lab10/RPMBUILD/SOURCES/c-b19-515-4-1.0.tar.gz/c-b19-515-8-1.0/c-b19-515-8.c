#include <stdio.h>

int main() {
    printf("Hello, world! From C! \n");
    return 0;
}
